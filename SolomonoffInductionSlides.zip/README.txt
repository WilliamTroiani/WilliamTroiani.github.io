Solomonoff Induction and Singular Integrals
Will Troiani | 28 October 2026

Extract this archive and open Solomonoff-Induction-and-Singular-Integrals.html
in Chrome, Edge, or Firefox. The slides and interactive sampler work offline.

Controls:
- Left and right arrows: move through the slides.
- F: enter or exit full screen.
- G: open the slide list.
- D: jump to the Bayesian sampler.

Based on joint work with Daniel Murfet.
Paper: https://arxiv.org/abs/2609.01666
