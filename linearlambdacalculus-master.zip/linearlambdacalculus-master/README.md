# linearlambdacalculus
Term assignment program
